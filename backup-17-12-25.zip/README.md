# Hackdash-aiweekend
Versión de hackdash para el aiweekend
