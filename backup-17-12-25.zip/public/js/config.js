const CONFIG = {
    // URL Absoluta a la API en producción
    API_BASE: 'https://aiday-utn-sanrafael-2025.alphadocere.cl/backend/public/',
    
    // Slug por defecto para el dashboard
    SLUG: 'hola' 
};

console.log('API conectada a:', CONFIG.API_BASE);