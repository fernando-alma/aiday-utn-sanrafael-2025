<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIDAY Los Reyunos</title>
    
    <meta name="theme-color" content="#F17158">
    <!-- Estilos -->
    <link rel="stylesheet" href="public/css/nav-styles.css">
    <link rel="stylesheet" href="public/css/styles.css">
    <link rel="stylesheet" href="public/css/landing.css">
    <link rel="stylesheet" href="public/css/footer.css">
    <link rel="stylesheet" href="public/css/marquee.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
</head>

<body>
    <div class="content-wrap">
        <section class="hero">
            <div class="hero-container">
                <h1 class="hero-title">
                    <img src="public/images/aiday-logo.png" width="280px" height="auto" alt="Logo Ai Day" /> <br>
                    Los Reyunos 2025
                </h1>
                <p class="hero-subtitle">
                    Dos días para conectar talento, empresas e Inteligencia Artificial en el corazón de Los Reyunos.
                </p>
                <div class="visual-banner-cta">
                    <a href="project-list" class="hero-cta">Ver Proyectos</a>
                </div>
            </div>

            <div class="container-stats">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number">2</div>
                        <div class="stat-label">Días</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">+100</div>
                        <div class="stat-label">Participantes</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">7</div>
                        <div class="stat-label">Speakers</div>
                    </div>
                </div>
            </div>

        </section>
        </section>

        <section class="features-section">
            <div class="container">
                <h2 class="section-title">¿Por qué AI Weekend?</h2>
                <div class="features-grid">
                    <div class="feature-card">
                        <h3 class="feature-title">Aprendizaje y Mentoría</h3>
                        <p class="feature-description">Sesiones de la mano de expertos y referentes de la industria.
                            Aprende las últimas tendencias de la IA.</p>
                    </div>
                    <div class="feature-card">
                        <h3 class="feature-title">Networking Real</h3>
                        <p class="feature-description">Conecta con desarrolladores, emprendedores e inversores. Crea
                            lazos profesionales de alto valor.</p>
                    </div>
                    <div class="feature-card">
                        <h3 class="feature-title">Impacto Social</h3>
                        <p class="feature-description">Contribuye a la formación de una comunidad tecnológica más fuerte
                            e inclusiva en la región.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="cta-padre">
            <div class="cta-proyectos">
                <img src="./public/images/desarrolladora.png" alt="AI Comunidad">

            </div>
            <div class="visual-banner-cta">
                <a href="project-list" class="hero-cta">Ver Proyectos UTN FRSR</a>
            </div>
            
        </section>


        <section class="community-section">
            <div class="container">
            </div>
            <div class="community-header">
                <h2 class="section-title">Speakeners</h2>
                <p class="community-subtitle">Aprende de expertos de la industria y líderes de opinión</p>
            </div>

            <div class="collaborators-grid">
                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Alejandro Bacic.png" alt="Foto de perfil"
                            class="collaborator-img">
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Alejandro Bacic</h3>
                        <div class="collaborator-role">AIWKND</div>
                        <br>
                        <p class="collaborator-bio">AI FUTURO - ICONNECT</p>

                    </div>
                </div>

                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Damian Kesler.png" alt="Foto de perfil"
                            class="collaborator-img">
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Damián Kesler</h3>
                        <div class="collaborator-role">NOVEDADESIA.SR</div>
                        <br>
                        <p class="collaborator-bio">La evolución de la IA, info noticias, actualidad y usos de la
                            IA.</p>

                    </div>
                </div>
                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Antonella Calabro.png" alt="Foto de perfil"
                            class="collaborator-img">
                    </div>

                    <div class="card-content">
                        <h3 class="collaborator-name">Antonella Calabró</h3>
                        <div class="collaborator-role">Pdta. PIT REGIÓN SUR MENDOZA</div>
                        <br>
                        <p class="collaborator-bio">Upskills para el futuro: Cómo UX, Dev y producto construyen
                            juntos en la era de la IA.</p>
                    </div>
                </div>



            </div>
            <div class="collaborators-grid">
                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Alejandro Alegre.png" alt="Foto de perfil"
                            class="collaborator-img">
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Alejandro Alegre</h3>
                        <div class="collaborator-role">VIVA STUDIO</div>
                        <br>
                        <p class="collaborator-bio">IMPOSSIBLE AI NOTHING</p>

                    </div>
                </div>

                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Lautaro Silva.png" alt="Foto de perfil"
                            class="collaborator-img">
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Lautaro Silva</h3>
                        <div class="collaborator-role">SENTINEL</div>
                        <br>
                        <p class="collaborator-bio"></p>

                    </div>
                </div>

                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Agus Muñoz.png" alt="Foto de perfil" class="collaborator-img">
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Agus Muñoz</h3>
                        <div class="collaborator-role">CONDOR VIEW</div>
                        <br>
                        <p class="collaborator-bio"></p>

                    </div>
                </div>

                <div class="collaborator-card">
                    <div class="card-image-container">
                        <img src="public/images/speakers/Mauro Rojas.png" alt="Foto de perfil" class="collaborator-img">
                        <!--<video src="public/images/speakers" class="video_flash" autoplay mute />-->
                    </div>
                    <div class="card-content">
                        <h3 class="collaborator-name">Mauro Rojas</h3>
                        <div class="collaborator-role">ALPHA DOCERE</div>
                        <br>
                        <p class="collaborator-bio"></p>

                    </div>
                </div>
                <!-- Más collaborator-cards limpias y coherentes -->
            </div>
    </div>
    </section>

    </div>

    <section class="schedule-section">
        <div class="container">
            <h2 class="section-title">Cronograma del Evento:</h2>

            <ul class="schedule-list">
                <div class="date-pill">
                    <span class="date-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5" />
                        </svg>
                    </span>
                    <span class="date-text">Viernes 12 de Diciembre, 2025</span>
                </div>
                <li class="schedule-item">
                    <span class="schedule-time">09:30–09:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Bienvenida y Recibimiento</div>
                        <div class="schedule-speaker">Recepción de asistentes</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">09:45–10:00</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Networking inicial</div>
                        <div class="schedule-speaker">Guía a espacio de networking</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">10:00–10:30</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Apertura y Homenaje</div>
                        <div class="schedule-speaker">Autoridades UTN (Homenaje Bocha Pessano)</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">10:35–10:55</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación AI DAY</div>
                        <div class="schedule-speaker">Equipo Aiweekend, Polo Tic, Alpha Docere</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">11:00–11:20</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación Condor View</div>
                        <div class="schedule-speaker">Jóvenes UTN</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">11:20–11:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación Sentinel</div>
                        <div class="schedule-speaker">Jóvenes UTN</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">12:10–12:30</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación Aiweekend</div>
                        <div class="schedule-speaker">Ale Bacic</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">12:35–12:55</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación Aiweekend</div>
                        <div class="schedule-speaker">Damián Keler</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">13:20–13:45</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Pit Región Sur Mendoza</div>
                        <div class="schedule-speaker">Antonela Calabro</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">13:50–14:00</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Interacción con público</div>
                        <div class="schedule-speaker">Alejandro Alegre</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">15:20–15:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Proyecto Los Reyunos</div>
                        <div class="schedule-speaker">Melina</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">15:40–17:45</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Workshops Rotativos</div>
                        <div class="schedule-speaker">Pitch, Sostenibilidad, Podcast, Proyecto UTN</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">18:00-18:30</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Cierre día 1 / Coffee Final</div>
                        <div class="schedule-speaker">Fin de jornada</div>
                    </div>
                </li>
            </ul>
            <ul class="schedule-list">
                <div class="date-pill">
                    <span class="date-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5" />
                        </svg>
                    </span>
                    <span class="date-text">Sábado 13 de Diciembre, 2025</span>
                </div>
                <li class="schedule-item">
                    <span class="schedule-time">09:30–09:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Bienvenida</div>
                        <div class="schedule-speaker">Recepción de asistentes</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">09:45–10:00</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Recibimiento</div>
                        <div class="schedule-speaker">Guía a espacio de networking inicial</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">10:00–10:30</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Presentación Alpha Docere</div>
                        <div class="schedule-speaker">Cosecha debate viernes</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">10:50–11:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Grupo 1</div>
                        <div class="schedule-speaker">5 primeras presentaciones</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">11:50–12:40</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Grupo 2</div>
                        <div class="schedule-speaker">5 siguientes presentaciones</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">12:55–13:45</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Grupo 3</div>
                        <div class="schedule-speaker">5 siguientes presentaciones</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">13:45–14:10</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Palabras UTN / Bienvenidos al mundo laboral</div>
                        <div class="schedule-speaker">Pit Región Sur Mendoza</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">14:20–15:05</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Grupo 4</div>
                        <div class="schedule-speaker">5 siguientes presentaciones</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">15:10–16:00</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Espacio networking intencionado</div>
                        <div class="schedule-speaker">PoloTic / Estudiantes UTN</div>
                    </div>
                </li>

                <li class="schedule-item">
                    <span class="schedule-time">16:00–18:00</span>
                    <div class="schedule-details">
                        <div class="schedule-event">Celebración</div>
                        <div class="schedule-speaker">Posible ASADO post evento / Uso instalaciones UTN</div>
                    </div>
                </li>
            </ul>

        </div>
        <div class="helpers-logos">
            <div id="marquee">
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/utn-bg-remove.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/alfa-vertical.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/utn-bg-remove.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/alfa-vertical.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/utn-bg-remove.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/aiwkndlogo.png" alt="" />
                </a>
                <a href="#" target="_blank" title="">
                    <img src="public/images/alfa-vertical.png" alt="" />
                </a>
                
            </div>
            <div class="shadow__right"></div>
            <div class="shadow__left"></div>
    </section>

    <section class="ai-community-full">
        <div class="ai-community-full-content">
            <div class="ai-community-illustration">
                <img src="./public/images/ai-community.png" alt="AI Comunidad">
            </div>

            <h2 class="ai-community-title">AiComunidad</h2>

            <p class="ai-community-subtitle">
                Conéctate con miles de entusiastas de la IA, desarrolladores e innovadores.
                Asiste a eventos, participa en hackathons y construye el futuro juntos.
            </p>

            <div class="ai-community-buttons">
                <a href="register" class="ai-btn-primary">Únete Ahora</a>
                <a href="community" class="ai-btn-secondary">Conoce Más</a>
            </div>
        </div>
    </section>
    <?php require_once("components/nav.php"); ?>
    <?php require_once("components/footer.php"); ?>

</body>



</html>