<?php

return [
    '' => __DIR__ . '/views/landing.php',
    'index' => __DIR__ . '/views/landing.php',
    'login' => __DIR__ . '/views/login.php',
    'register' => __DIR__ . '/views/register.php',
    'recover-password' => __DIR__ . '/views/recover-password.php',
    'profile' => __DIR__ . '/views/profile.php',
    'project-list' => __DIR__ . '/views/project-list.php',
    'project-detail' => __DIR__ . '/views/project-detail.php',
    'project-create' => __DIR__ . '/views/project-create.php',
    'project-edit' => __DIR__ . '/views/project-edit.php',
    'not-found' => __DIR__ . '/views/not-found.php',
];
